#!/bin/sh
set -eu

nice '/home/mfcl/mfclo64' 'bet.frq' 'aspm-input-final.par' 'aspm.par' '-file' '-' < 'aspm_control.txt'
