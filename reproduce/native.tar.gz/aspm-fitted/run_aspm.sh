#!/bin/sh
set -eu

nice '/home/mfcl/mfclo64' 'bet.frq' 'aspm-input-aspm.par' 'aspm-restart-1.par' '-file' '-' < 'aspm_control.txt'
