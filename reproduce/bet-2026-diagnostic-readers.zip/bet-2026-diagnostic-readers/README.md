# BET Diagnostic native readers

Use base R and Make; no Python or downloads. `make unpack` exposes ordinary
MFCL/PAR/input/script files and two pinned shared engines. `make verify` checks
the exact files. Use a fresh absolute OUT for preparation or execution.

Diagnostic: `make rerun CASE=diagnostic OUT=/tmp/bet-diagnostic-new`.
Profiles: `make profiles CASE=profiles OUT=/tmp/bet-profile-new`; 44 retained
profile PARs plus the scalar-100 anchor use the original zero-penalty switches
and ceiling one. Original generated continuation scripts were not retained;
`refit` is available only for the unchanged self-contained Diagnostic recipe.

ASPM: `make aspm CASE=constant OUT=/tmp/bet-aspm-constant-new` or
`make aspm CASE=fitted OUT=/tmp/bet-aspm-fitted-new`. These require complete
original REP hashes. The fitted replay uses the original pre-restart PAR; its
terminal PAR and restart input remain unavailable. It is not a terminal-PAR rerun.

Execution requires Linux x86-64. Archive/prepare checks do not execute MFCL.
Full-refit equality, whole profile REP equality and Hessian regeneration are
not established by these reader commands. `source-manifest.json` retains exact
original source pins and the unchanged compact archive identity.
