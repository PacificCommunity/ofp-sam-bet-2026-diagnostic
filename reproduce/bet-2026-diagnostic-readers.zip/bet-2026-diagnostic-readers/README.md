# BET Diagnostic native readers

Use base R and Make; no Python or downloads. `make unpack` exposes ordinary
MFCL/PAR/input/script files and two pinned shared engines. `make verify` checks
the exact files. Use a fresh absolute OUT for preparation or execution.

Diagnostic: `make rerun CASE=diagnostic OUT=/tmp/bet-diagnostic-new`.
Profiles: `make profiles CASE=profiles OUT=/tmp/bet-profile-new`; 44 retained
profile PARs plus the scalar-100 anchor use the original zero-penalty switches
and ceiling one. Observed parameter counts and zero iteration/function counters
are mandatory, alongside finite REP dimensions/shapes and original average-biomass
targets. Scalar100 also checks archived central arrays; other profile time-series
equality is not established. Original continuation scripts were not retained;
`refit` is available only for the unchanged self-contained Diagnostic recipe.

ASPM: `make aspm CASE=constant OUT=/tmp/bet-aspm-constant-new` or
`make aspm CASE=fitted OUT=/tmp/bet-aspm-fitted-new`. These require complete
original REP hashes. The fitted replay uses the original pre-restart PAR; its
terminal PAR and restart input remain unavailable. It is not a terminal-PAR rerun.

Execution requires Linux x86-64. Archive/prepare checks do not execute MFCL.
Full-refit equality, whole profile REP equality and Hessian regeneration are
not established by these reader commands. `source-manifest.json` retains exact
original source pins and the unchanged compact archive identity.

Generated profile-only controls set flag50=6; reported criterion1e6 and every
observed counter zero are required. This evaluates high-gradient saved PARs;
fit convergence is not established. The fixed CLI ceiling1 is distinguished
from logged control evidence. Exact argv is saved in native-command.txt.

Constrained profile output requires fished biomass/recruitment and original
dimensions/biomass targets. Available unfished/MSY sections are also checked;
Diagnostic, scalar100 and ASPM retain mandatory complete central fields.
